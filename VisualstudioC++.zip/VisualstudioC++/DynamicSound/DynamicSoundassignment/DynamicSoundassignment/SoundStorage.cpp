#include "SoundStorage.h"

void SoundLoader::initializeSound()
{
	manage.Init();

	 
	// registering sound files to map
	//Frog Sounds
	soundMap[1] = "Plugins/media/Attacks/frog attack.mp3";
	soundMap[2] = "Plugins/media/Idle sounds/ribbit.mp3";
	soundMap[3] = "Plugins/media/movement/Frog hop.mp3";
	soundMap[4] = "Plugins/media/Taunts/ Frog Taunt.mp3";
				   
	//Mouse sounds 
	soundMap[11] = "Plugins/media/Attacks/Mouse_Attack.mp3";
	soundMap[12] = "Plugins/media/Attacks/Mouse_2nd Attack.mp3";
	soundMap[13] = "Plugins/media/Idle sounds/Squeak.mp3";
	soundMap[14] = "Plugins/media/movement/Mouse run.mp3";
	soundMap[15] = "Plugins/media/Taunts/Mouse taunt.mp3";
				  
	// Spider Sounds
	soundMap[21] = "Plugins/media/Attacks/Spider thwip.mp3";
	soundMap[22] = "Plugins/media/Idle sounds/ Spider click.mp3";
	soundMap[23] = "Plugins/media/movement/Spider Walk.mp3";
	soundMap[24] = "Plugins/media/Taunts/Spider Taunt.mp3";
				   
	//Snake sounds 
	soundMap[31] = "Plugins/media/Attacks/ Snake bite.mp3";
	soundMap[32] = "Plugins/media/movement/Snake movement.mp3";
	soundMap[33] = "Plugins/media/Taunts/Snake Taunt.mp3";



}

void SoundLoader::loadSound(int key)
{
	//loading the sound to play
	result = manage.system->createSound(soundMap[key], FMOD_3D, 0, &sound);
	FmodErrorCheck(result);
	result = sound->set3DMinMaxDistance(0.5f, 300.0f);
	FmodErrorCheck(result);
	result = sound->setMode(FMOD_3D);
	FmodErrorCheck(result);
}

void SoundLoader::playSound()
{
	//play sound
	result = manage.system->playSound(sound, 0, true, &channel);
	FmodErrorCheck(result);
	result = channel->set3DAttributes(&pos, &vel);
	FmodErrorCheck(result);
	result = channel->setPaused(false);
	FmodErrorCheck(result);
	//system("pause"); //only use in C++ LEAVE COMENTED OUT FOR UNITY!!!

	//clean up
	result = sound->release();
	FmodErrorCheck(result);
}
